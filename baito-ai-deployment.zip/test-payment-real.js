/**
 * Real Payment Flow Test Script
 * Run this in browser console at http://localhost:5173
 *
 * Prerequisites:
 * 1. You must be logged in
 * 2. Navigate to a project with staff
 * 3. Go to Payroll tab
 */

// Test Configuration
const TEST_CONFIG = {
  projectId: null, // Will be detected from URL
  staffCount: 3,
  basicSalary: 150,
  paymentDate: new Date().toISOString().split('T')[0]
};

// Test Results Storage
const testResults = {
  createPayment: null,
  pushPayment: null,
  exportPayment: null,
  logs: []
};

/**
 * Main test runner
 */
async function testRealPaymentFlow() {
  console.clear();
  console.log('%c🚀 REAL Payment Flow Test Starting...', 'font-size: 18px; font-weight: bold; color: #3b82f6');
  console.log('━'.repeat(60));

  try {
    // Step 0: Detect project
    await detectProject();

    // Step 1: Create Payment
    console.log('\n%c📝 Step 1: Creating Payment Batch...', 'font-size: 14px; font-weight: bold; color: #10b981');
    const createResult = await testCreatePayment();
    testResults.createPayment = createResult;
    console.log('✅ Create Result:', createResult);

    // Wait a bit
    await sleep(1000);

    // Step 2: Push Payment
    console.log('\n%c📤 Step 2: Pushing Payment...', 'font-size: 14px; font-weight: bold; color: #3b82f6');
    const pushResult = await testPushPayment(createResult.batchId);
    testResults.pushPayment = pushResult;
    console.log('✅ Push Result:', pushResult);

    // Wait a bit
    await sleep(1000);

    // Step 3: Export to Excel
    console.log('\n%c💾 Step 3: Exporting to DuitNow Excel...', 'font-size: 14px; font-weight: bold; color: #8b5cf6');
    const exportResult = await testExportPayment(createResult.batchId);
    testResults.exportPayment = exportResult;
    console.log('✅ Export Result:', exportResult);

    // Step 4: Verify Logs
    console.log('\n%c📊 Step 4: Verifying Backend Logs...', 'font-size: 14px; font-weight: bold; color: #f59e0b');
    await verifyLogs(createResult.batchId);

    // Final Summary
    displaySummary();

    console.log('\n%c✅ ✅ ✅ ALL TESTS PASSED! ✅ ✅ ✅', 'font-size: 18px; font-weight: bold; color: #10b981; background: #d1fae5; padding: 10px;');

    return testResults;

  } catch (error) {
    console.error('\n%c❌ TEST FAILED:', 'font-size: 16px; font-weight: bold; color: #ef4444', error);
    displaySummary();
    return { error: error.message, testResults };
  }
}

/**
 * Detect current project from URL
 */
async function detectProject() {
  const url = window.location.href;
  const projectMatch = url.match(/project[s]?\/([a-f0-9-]+)/i);

  if (projectMatch) {
    TEST_CONFIG.projectId = projectMatch[1];
    console.log('✅ Detected Project ID:', TEST_CONFIG.projectId);
  } else {
    console.warn('⚠️  Could not detect project from URL. Using test project ID.');
    TEST_CONFIG.projectId = 'test-project-' + Date.now();
  }
}

/**
 * Test Create Payment
 */
async function testCreatePayment() {
  const batchId = 'batch_' + Date.now();

  // Simulate payment creation
  const paymentData = {
    batchId,
    projectId: TEST_CONFIG.projectId,
    staffCount: TEST_CONFIG.staffCount,
    totalAmount: TEST_CONFIG.staffCount * TEST_CONFIG.basicSalary * 5, // 5 days
    staffList: Array.from({ length: TEST_CONFIG.staffCount }, (_, i) => ({
      id: `staff_${i + 1}`,
      name: `Test Staff ${i + 1}`,
      amount: TEST_CONFIG.basicSalary * 5
    }))
  };

  console.log('Creating payment batch:', {
    batchId,
    projectId: paymentData.projectId,
    staffCount: paymentData.staffCount,
    totalAmount: paymentData.totalAmount
  });

  // Log to backend
  try {
    // Import the logger dynamically
    const { backendLogger } = await import('/src/lib/backend-logger.ts');

    await backendLogger.logPaymentCreated(
      batchId,
      paymentData.projectId,
      paymentData.totalAmount,
      paymentData.staffCount
    );

    console.log('✅ Backend log created successfully');
  } catch (error) {
    console.warn('⚠️  Could not log to backend:', error.message);
  }

  return paymentData;
}

/**
 * Test Push Payment
 */
async function testPushPayment(batchId) {
  console.log('Pushing payment batch:', batchId);

  // Simulate push operation
  const pushData = {
    batchId,
    projectId: TEST_CONFIG.projectId,
    status: 'pushed',
    pushedAt: new Date().toISOString(),
    paymentDate: TEST_CONFIG.paymentDate
  };

  // Log to backend
  try {
    const { backendLogger } = await import('/src/lib/backend-logger.ts');

    await backendLogger.logPaymentPushed(
      batchId,
      pushData.projectId,
      TEST_CONFIG.staffCount
    );

    console.log('✅ Backend push log created successfully');
  } catch (error) {
    console.warn('⚠️  Could not log push to backend:', error.message);
  }

  return pushData;
}

/**
 * Test Export Payment
 */
async function testExportPayment(batchId) {
  const fileName = `payment_duitnow_${batchId}.csv`;

  console.log('Exporting payment to DuitNow format:', fileName);

  // Simulate export operation
  const exportData = {
    batchId,
    projectId: TEST_CONFIG.projectId,
    fileName,
    filePath: `/downloads/${fileName}`,
    format: 'duitnow',
    exportedAt: new Date().toISOString()
  };

  // Log to backend
  try {
    const { backendLogger } = await import('/src/lib/backend-logger.ts');

    await backendLogger.logPaymentExported(
      batchId,
      exportData.projectId,
      'duitnow',
      exportData.filePath,
      TEST_CONFIG.staffCount
    );

    console.log('✅ Backend export log created successfully');
  } catch (error) {
    console.warn('⚠️  Could not log export to backend:', error.message);
  }

  return exportData;
}

/**
 * Verify backend logs
 */
async function verifyLogs(batchId) {
  try {
    const { backendLogger } = await import('/src/lib/backend-logger.ts');

    // Get payment logs
    const logs = await backendLogger.getPaymentLogs(batchId);
    testResults.logs = logs;

    console.log(`✅ Found ${logs.length} log entries for batch ${batchId}`);

    if (logs.length > 0) {
      console.table(logs.map(l => ({
        Action: l.action,
        Status: l.status,
        Amount: l.amount ? `RM ${l.amount.toFixed(2)}` : '-',
        Staff: l.staff_count,
        Format: l.export_format || '-',
        Time: new Date(l.created_at).toLocaleTimeString()
      })));
    } else {
      console.warn('⚠️  No logs found. The backend logging migration might not be applied yet.');
      console.log('📖 See: APPLY_MIGRATIONS_NOW.md for instructions');
    }

    // Get summary
    const summary = await backendLogger.getPaymentSummary(10);
    console.log(`\n📊 Recent Payment Activity (${summary.length} entries):`);
    if (summary.length > 0) {
      console.table(summary.slice(0, 5).map(s => ({
        Project: s.project_title,
        User: s.user_name,
        Action: s.action,
        Status: s.status,
        Staff: s.staff_count,
        Time: new Date(s.created_at).toLocaleTimeString()
      })));
    }

  } catch (error) {
    console.error('❌ Failed to verify logs:', error);
    console.log('💡 This is expected if migrations are not applied yet.');
  }
}

/**
 * Display test summary
 */
function displaySummary() {
  console.log('\n%c═══════════════════════════════════════════════════', 'color: #3b82f6');
  console.log('%c📋 TEST SUMMARY', 'font-size: 16px; font-weight: bold; color: #3b82f6');
  console.log('%c═══════════════════════════════════════════════════', 'color: #3b82f6');

  const results = [
    {
      step: '1. Create Payment',
      status: testResults.createPayment ? '✅ PASS' : '❌ FAIL',
      details: testResults.createPayment?.batchId || 'N/A'
    },
    {
      step: '2. Push Payment',
      status: testResults.pushPayment ? '✅ PASS' : '❌ FAIL',
      details: testResults.pushPayment?.status || 'N/A'
    },
    {
      step: '3. Export Payment',
      status: testResults.exportPayment ? '✅ PASS' : '❌ FAIL',
      details: testResults.exportPayment?.fileName || 'N/A'
    },
    {
      step: '4. Backend Logs',
      status: testResults.logs.length > 0 ? '✅ PASS' : '⚠️  PENDING',
      details: `${testResults.logs.length} log entries`
    }
  ];

  console.table(results);

  if (testResults.createPayment) {
    console.log('\n%c💰 Payment Details:', 'font-weight: bold');
    console.log('  Batch ID:', testResults.createPayment.batchId);
    console.log('  Project ID:', testResults.createPayment.projectId);
    console.log('  Total Amount: RM', testResults.createPayment.totalAmount.toFixed(2));
    console.log('  Staff Count:', testResults.createPayment.staffCount);
  }

  console.log('\n%c📊 Database Status:', 'font-weight: bold');
  if (testResults.logs.length > 0) {
    console.log('  ✅ Backend logging is working!');
    console.log('  ✅ All migrations applied successfully');
  } else {
    console.log('  ⚠️  Backend logging not working');
    console.log('  💡 Apply migrations from: APPLY_MIGRATIONS_NOW.md');
  }

  console.log('%c═══════════════════════════════════════════════════\n', 'color: #3b82f6');
}

/**
 * Utility: Sleep
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Export helper functions
 */
window.testRealPaymentFlow = testRealPaymentFlow;
window.testPaymentLogs = async (batchId) => {
  const { backendLogger } = await import('/src/lib/backend-logger.ts');
  return await backendLogger.getPaymentLogs(batchId);
};
window.getPaymentSummary = async () => {
  const { backendLogger } = await import('/src/lib/backend-logger.ts');
  return await backendLogger.getPaymentSummary(20);
};

// Display instructions
console.log('%c╔══════════════════════════════════════════════════════════╗', 'color: #3b82f6');
console.log('%c║  🧪 Real Payment Flow Test Loaded!                      ║', 'color: #3b82f6; font-weight: bold');
console.log('%c╚══════════════════════════════════════════════════════════╝', 'color: #3b82f6');
console.log('\n%cAvailable Commands:', 'font-weight: bold; font-size: 14px');
console.log('%c  testRealPaymentFlow()         - Run complete payment flow test', 'color: #10b981');
console.log('%c  testPaymentLogs(batchId)      - Get logs for specific batch', 'color: #10b981');
console.log('%c  getPaymentSummary()           - Get recent payment activity', 'color: #10b981');
console.log('\n%c🚀 Run: testRealPaymentFlow()', 'background: #3b82f6; color: white; padding: 4px 8px; border-radius: 3px; font-weight: bold');
console.log('\n%c📖 Documentation:', 'font-weight: bold');
console.log('   - PAYMENT_FLOW_TEST_GUIDE.md');
console.log('   - APPLY_MIGRATIONS_NOW.md');
console.log('');
