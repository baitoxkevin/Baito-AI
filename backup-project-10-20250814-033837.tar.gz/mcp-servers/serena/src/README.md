Serena uses (modified) versions of other libraries/packages:

 * [multilspy](https://github.com/oraios/multilspy) (for language server protocol support); original repo: microsoft/multilspy
 * [interprompt](https://github.com/oraios/interprompt) (our prompt templating library)
