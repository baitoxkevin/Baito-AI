-- Disable RLS on project_documents table entirely
ALTER TABLE project_documents DISABLE ROW LEVEL SECURITY;